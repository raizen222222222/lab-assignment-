# Lab Assignment 2 - Portfolio Website (Aryan)

This is Aryan's Lab Assignment 2 project for 1st Semester.

## Sections
- Hero Section
- About Me
- Education
- Projects
- Skills
- Contact Form

## Features
- Clean and academic blue-white theme
- External CSS styling with Google Fonts
- Sticky Navigation Bar
- Back-to-top button
- Hover effects on projects and buttons

Author: Aryan (B.Tech CSE - 1st Semester)
